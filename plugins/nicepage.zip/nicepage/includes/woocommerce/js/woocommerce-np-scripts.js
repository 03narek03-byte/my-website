jQuery(document).ready(function($) {
    if (jQuery('form.woocommerce-checkout').length) {
        jQuery('form.woocommerce-checkout').on('checkout_place_order', function () {
            prepareCheckoutForm();
            return true;
        });
        jQuery('body').on('change', '.u-checkout-form form :input', prepareCheckoutForm);
        jQuery('body').on('change', '.u-checkout-form-order :input:not(.shipping_method)', prepareCheckoutForm);
        prepareCheckoutForm();
        // Shipping Address fields
        jQuery('div.shipping_address').hide();
        jQuery('body').on('change', '#ship-to-different-address input', function () {
            jQuery('div.shipping_address').hide();
            if (jQuery(this).is(':checked') ) {
                jQuery('div.shipping_address').slideDown();
            }
        });
        jQuery('body').on('change', 'input[name^="shipping_method"]', function () {
            jQuery('.u-checkout-placeorder-form form .data-from-checkout-form .shipping_method').removeAttr('checked').prop('checked', false);
            jQuery('.u-checkout-placeorder-form form .data-from-checkout-form .shipping_method[value="'+ jQuery(this).val() + '"]').attr('checked', '').prop('checked', true);
            jQuery(document.body).trigger("update_checkout");
        });
    }
    jQuery(document).on('click', '.u-product .u-btn.u-product-control', function(e) {
        e.preventDefault();
        jQuery(this).parents('.u-product').find('.single_add_to_cart_button').click();
    });
    function changeVariationOptions() {
        var variationForm = jQuery('.variations_form');
        variationForm.on('show_variation', function(event, variation, purchasable) {
            if (variation.sku) {
                jQuery('.u-product-control.u-product-sku').text(variation.sku);
            }
            if (variation.variation_description) {
                var variationDesc = jQuery('.variations_form div.u-product-control.np-variation-desc');
                if (variationDesc.length) {
                    variationDesc.html(variation.variation_description);
                } else {
                    jQuery('.u-product-variations:last').after(jQuery('div.u-product-control.u-text').eq(0).clone().html(variation.variation_description).addClass('np-variation-desc'));
                }
            }
        });
    }
    changeVariationOptions();
    function changePrice() {
        if (jQuery('.woocommerce-variation-price').length) {
            var priceControl = jQuery('.u-product-price:visible');
            if (priceControl.length > 1) {
                priceControl.each(function(index) {
                    if (index === 0) { return; }
                    priceControl[index].remove();
                });
            }
            if (jQuery('.woocommerce-variation-price .price ins').not(':visible').length && jQuery('.woocommerce-variation-price .price del').not(':visible').length) {
                priceControl.find('.u-price').html(jQuery('.woocommerce-variation-price .price ins').not(':visible').html());
                priceControl.find('.u-old-price').html(jQuery('.woocommerce-variation-price .price del').not(':visible').html());
            } else {
                priceControl.html(jQuery('.woocommerce-variation-price .u-product-price').not(':visible').html());
            }
        }
    }
    jQuery(document).on('show_variation', '.single_variation_wrap', function(event, variation) {
        changePrice();
    });
    jQuery(document).on('change', '.u-product-variant select', function() {
        setTimeout(changePrice, 100);
    });
    function changeQuantity() {
        var quantityWoocommerceInput = jQuery('input[name="quantity"]')
        if (quantityWoocommerceInput.length) {
            quantityWoocommerceInput.val(jQuery(this).find('.u-input').val());
        }
    }
    jQuery(document).on('change', '.u-quantity-input', changeQuantity);

    jQuery('[data-products-datasource="cms"] .u-select-sorting').change(function() {
        let selectedOption = $(this).children("option:selected").val();
        let url = new URL(window.location.href);
        let params = new URLSearchParams(url.search);
        params.delete('sorting');
        params.append('sorting', selectedOption);
        url.search = params.toString();
        let newUrl = url.toString();
        if (newUrl) {
            window.location.href = newUrl;
        }
    });
    jQuery('[data-products-datasource="cms"] .u-select-categories').change(function() {
        let selectedOption = jQuery(this).children("option:selected").val();
        let url = new URL(window.location.href);
        let params = new URLSearchParams(url.search);
        params.delete('categoryId');
        params.append('categoryId', selectedOption);
        url.search = params.toString();
        let newUrl = url.toString();
        if (newUrl) {
            window.location.href = newUrl;
        }
    });
});
function submitCheckoutForm() {
    jQuery('button#place_order').click();
}
function prepareCheckoutForm() {
    jQuery(document.body).trigger("update_checkout");
    jQuery('.u-checkout-placeorder-form form .data-from-checkout-form').html('');
    jQuery('.u-checkout-form form').find(':input').clone().appendTo('.u-checkout-placeorder-form form .data-from-checkout-form');
    jQuery('.u-checkout-form-order').find(':input').clone().appendTo('.u-checkout-placeorder-form form .data-from-checkout-form');
    var selects = jQuery('.u-checkout-form select');
    var id = '';
    for (let i = 0; i < selects.length; i++) {
        id = selects.eq(i).attr('id');
        var selectsTo = jQuery('.u-checkout-placeorder-form #' + id);
        var selectsFrom = jQuery('.u-checkout-form #' + id);
        if (id && selectsTo.length && selectsFrom.length) {
            selectsTo[0].selectedIndex = selectsFrom[0].selectedIndex;
        }
    }
}